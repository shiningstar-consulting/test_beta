<?php
return [
    "debug" => false,
    "name" => "test_beta",
    "timezone" => "Asia/Tokyo",
    "locale" => "ja",
];
