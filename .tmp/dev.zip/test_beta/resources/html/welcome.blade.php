@extends('template.base')

@section('content')
<h1 class="text-3xl font-bold underline text-clifford">
    Hello world!
</h1>
@endsection