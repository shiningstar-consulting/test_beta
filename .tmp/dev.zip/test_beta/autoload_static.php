<?php 
require_once 'test_beta/config/app.php';
require_once 'test_beta/app/Exceptions/ExceptionHandler.php';
require_once 'test_beta/app/Http/Controllers/Web/WelcomeController.php';
require_once 'test_beta/test_betaApplication.php';
