<?php 
require_once 'test_beta/app/Exceptions/ExceptionHandler.php';
require_once 'test_beta/app/Http/Controllers/Web/WelcomeController.php';
require_once 'test_beta/config/app.php';
require_once 'test_beta/routes/api.php';
require_once 'test_beta/routes/batch.php';
require_once 'test_beta/routes/web.php';
require_once 'test_beta/test_betaApplication.php';
